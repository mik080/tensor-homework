password: secretpass
run command: ansible-playbook main.yaml --ask-vault-pass
